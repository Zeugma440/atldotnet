# Library Documentation

[Project filestructure](Project-Structure)

[Software architecture](Software-architecture)

[Usage / Code snippets](Usage-_-Code-snippets)

[FAQ](FAQ)

